import { createServerSupabase } from '@/lib/supabase';
import { getOrgBySlug, getContacts, getMemberships } from '@/lib/queries';
import { DashboardView } from '@/components/dashboard/DashboardView';

export default async function DashboardPage({
  params,
}: {
  params: { orgSlug: string };
}) {
  const supabase = await createServerSupabase();
  const org = await getOrgBySlug(supabase, params.orgSlug);
  const contacts = await getContacts(supabase, org.id);
  const memberships = await getMemberships(supabase, org.id);

  // Get current user
  const { data: { user } } = await supabase.auth.getUser();
  const currentMembership = user
    ? memberships.find(m => m.user_id === user.id)
    : memberships[0];

  return (
    <DashboardView
      contacts={contacts}
      memberships={memberships}
      currentUserName={currentMembership?.display_name || memberships[0]?.display_name || 'User'}
      orgSlug={params.orgSlug}
    />
  );
}
