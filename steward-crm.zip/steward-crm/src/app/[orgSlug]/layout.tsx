import { createServerSupabase } from '@/lib/supabase';
import { getOrgBySlug, getMemberships } from '@/lib/queries';
import { OrgProvider } from '@/lib/org-context';
import { OrgNav } from '@/components/ui/OrgNav';
import { notFound } from 'next/navigation';

export default async function OrgLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { orgSlug: string };
}) {
  const supabase = await createServerSupabase();

  let org;
  try {
    org = await getOrgBySlug(supabase, params.orgSlug);
  } catch {
    notFound();
  }

  const memberships = await getMemberships(supabase, org.id);

  // Get current user's membership
  // TODO: Replace with actual auth when porting auth code
  const { data: { user } } = await supabase.auth.getUser();
  const currentMembership = user
    ? memberships.find(m => m.user_id === user.id) || null
    : memberships[0]; // Fallback to first member for demo

  return (
    <OrgProvider org={org} membership={currentMembership} memberships={memberships}>
      <div className="min-h-screen bg-sand-50">
        <OrgNav orgSlug={params.orgSlug} orgName={org.name} userName={currentMembership?.display_name || 'User'} />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-16">
          {children}
        </main>
      </div>
    </OrgProvider>
  );
}
