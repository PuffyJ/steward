import { createServerSupabase } from '@/lib/supabase';
import { getContact, getInteractionsByContact, getMemberships, getOrgBySlug } from '@/lib/queries';
import { Contact360View } from '@/components/contacts/Contact360View';
import { notFound } from 'next/navigation';

export default async function ContactDetailPage({
  params,
}: {
  params: { orgSlug: string; id: string };
}) {
  const supabase = await createServerSupabase();
  const org = await getOrgBySlug(supabase, params.orgSlug);

  let contact;
  try {
    contact = await getContact(supabase, params.id);
  } catch {
    notFound();
  }

  const interactions = await getInteractionsByContact(supabase, params.id);
  const memberships = await getMemberships(supabase, org.id);

  // Get current user membership
  const { data: { user } } = await supabase.auth.getUser();
  const currentMembership = user
    ? memberships.find(m => m.user_id === user.id)
    : memberships[0];

  return (
    <Contact360View
      contact={contact}
      interactions={interactions}
      memberships={memberships}
      currentMembershipId={currentMembership?.id || memberships[0]?.id || ''}
      orgSlug={params.orgSlug}
      orgId={org.id}
    />
  );
}
